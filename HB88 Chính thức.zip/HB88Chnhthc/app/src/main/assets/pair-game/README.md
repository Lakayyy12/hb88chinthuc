# Pair Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexandremasy/pen/NrgQQo](https://codepen.io/alexandremasy/pen/NrgQQo).

Simple game where you have to find the pairs. This is the base for a multiplayer game (2x2) where you have to beat the other one. 