package lim.jiyeon.hb88chnhthc.hb.eight

import androidx.annotation.Keep

@Keep
data class YeonDataCorp(
    val yeonone: String?,
    val yeontwo: String?,
    val yeonthree: String?,
    val yeonfour: String?,
    val yeonfive: Boolean?
)
